package com.spendtracker.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Profile(
    @PrimaryKey val id: Int = 1,
    val salary: Double,
    val fixedCredit: Double,
    val savingPercent: Int
) {
    /** Budget base: fixed monthly credit if given, else salary */
    fun base(): Double = if (fixedCredit > 0) fixedCredit else salary
}

@Entity
data class FixedExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val amount: Double
)

/** Every notification seen on the phone. Kept forever (month tagged). */
@Entity(indices = [Index("monthKey")])
data class NotifEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pkg: String,
    val title: String,
    val text: String,
    val time: Long,
    val monthKey: String,      // e.g. 2026-10
    val isTruecaller: Boolean
)

/** Parsed bank debit/credit. */
@Entity(indices = [Index(value = ["dedupKey"], unique = true), Index("monthKey"), Index("dayKey")])
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val type: String,          // DEBIT or CREDIT
    val body: String,
    val source: String,        // package name or "SMS"
    val time: Long,
    val dayKey: String,        // 2026-10-23
    val monthKey: String,
    val dedupKey: String
)

@Entity
data class DailyReport(
    @PrimaryKey val dayKey: String,
    val monthKey: String,
    val limit: Double,
    val spent: Double,
    val credited: Double,
    val crossed: Boolean
)

@Dao
interface AppDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveProfile(p: Profile)
    @Query("SELECT * FROM Profile WHERE id=1") fun profile(): Flow<Profile?>
    @Query("SELECT * FROM Profile WHERE id=1") suspend fun profileOnce(): Profile?

    @Insert suspend fun addExpense(e: FixedExpense)
    @Query("DELETE FROM FixedExpense") suspend fun clearExpenses()
    @Query("SELECT * FROM FixedExpense") fun expenses(): Flow<List<FixedExpense>>
    @Query("SELECT * FROM FixedExpense") suspend fun expensesOnce(): List<FixedExpense>

    @Insert suspend fun addNotif(n: NotifEntity)
    @Query("SELECT COUNT(*) FROM NotifEntity WHERE monthKey=:m") fun notifCount(m: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addTxn(t: Txn): Long
    @Query("SELECT * FROM Txn WHERE dayKey=:d ORDER BY time DESC") fun txnsOfDay(d: String): Flow<List<Txn>>
    @Query("SELECT COALESCE(SUM(amount),0) FROM Txn WHERE dayKey=:d AND type='DEBIT'") fun daySpentFlow(d: String): Flow<Double>
    @Query("SELECT COALESCE(SUM(amount),0) FROM Txn WHERE dayKey=:d AND type='DEBIT'") suspend fun daySpent(d: String): Double
    @Query("SELECT COALESCE(SUM(amount),0) FROM Txn WHERE dayKey=:d AND type='CREDIT'") suspend fun dayCredit(d: String): Double
    @Query("SELECT COALESCE(SUM(amount),0) FROM Txn WHERE monthKey=:m AND type='DEBIT'") fun monthSpentFlow(m: String): Flow<Double>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveReport(r: DailyReport)
    @Query("SELECT * FROM DailyReport ORDER BY dayKey DESC") fun reports(): Flow<List<DailyReport>>
}

@Database(
    entities = [Profile::class, FixedExpense::class, NotifEntity::class, Txn::class, DailyReport::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "spend.db")
                .build().also { inst = it }
        }
    }
}
