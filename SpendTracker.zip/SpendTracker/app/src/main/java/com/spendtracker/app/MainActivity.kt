package com.spendtracker.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

data class Opt(val p: Profile?)
class ExpRow(name: String, amount: String = "") {
    var name by mutableStateOf(name)
    var amount by mutableStateOf(amount)
}

fun rs(d: Double) = "₹" + String.format("%,.0f", d)

@Composable
fun App() {
    val ctx = LocalContext.current
    val dao = remember { AppDatabase.get(ctx).dao() }
    val opt by remember { dao.profile().map { Opt(it) } }.collectAsState(initial = null)
    val o = opt
    when {
        o == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        o.p == null -> SetupFlow(dao)
        else -> Dashboard(dao, o.p)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SetupFlow(dao: AppDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(1) }
    var salary by remember { mutableStateOf("") }
    var fixedCredit by remember { mutableStateOf("") }
    val rows = remember { mutableStateListOf<ExpRow>() }
    var pct by remember { mutableFloatStateOf(20f) }
    val suggestions = listOf("SIP", "EMI", "Rent", "Bijli/Pani/Gas", "Mobile/Internet",
        "Insurance", "Ghar ko bhejna", "Subscriptions", "Other")

    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Setup  ($step/3)", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        if (step == 1) {
            Text("Aapki income")
            OutlinedTextField(salary, { salary = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Monthly salary (₹)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(fixedCredit, { fixedCredit = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Account me fix credit hone wala amount (₹)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("Khali chhodoge to salary hi base maani jayegi.", fontSize = 12.sp)
            Button(onClick = { step = 2 }, enabled = (salary.toDoubleOrNull() ?: 0.0) > 0 || (fixedCredit.toDoubleOrNull() ?: 0.0) > 0) { Text("Next") }
        }

        if (step == 2) {
            Text("Fix kharche (har mahine)")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                suggestions.forEach { s -> AssistChip(onClick = { rows.add(ExpRow(if (s == "Other") "" else s)) }, label = { Text("+ $s") }) }
            }
            rows.forEachIndexed { i, r ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(r.name, { r.name = it }, label = { Text("Naam") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(r.amount, { r.amount = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("₹") }, modifier = Modifier.weight(0.7f), singleLine = true)
                    TextButton(onClick = { rows.removeAt(i) }) { Text("X") }
                }
            }
            val total = rows.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
            Text("Total fix kharch: ${rs(total)}", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { step = 1 }) { Text("Back") }
                Button(onClick = { step = 3 }) { Text("Next") }
            }
        }

        if (step == 3) {
            val base = (fixedCredit.toDoubleOrNull()?.takeIf { it > 0 } ?: salary.toDoubleOrNull() ?: 0.0)
            val fixed = rows.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
            val plan = Formula.compute(base, fixed, pct.toInt(), YearMonth.now().lengthOfMonth())
            Text("Saving: ${pct.toInt()}% of income")
            Slider(pct, { pct = it }, valueRange = 0f..50f)
            PlanCard(plan)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { step = 2 }) { Text("Back") }
                Button(onClick = {
                    scope.launch {
                        dao.clearExpenses()
                        rows.filter { (it.amount.toDoubleOrNull() ?: 0.0) > 0 }
                            .forEach { dao.addExpense(FixedExpense(name = it.name.ifBlank { "Other" }, amount = it.amount.toDouble())) }
                        dao.saveProfile(Profile(1, salary.toDoubleOrNull() ?: 0.0, fixedCredit.toDoubleOrNull() ?: 0.0, pct.toInt()))
                        Scheduler.scheduleAll(ctx)
                    }
                }) { Text("Save & Start") }
            }
        }
    }
}

@Composable
fun PlanCard(plan: Plan) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Income: ${rs(plan.base)}")
            Text("Fix kharche: − ${rs(plan.fixedTotal)}")
            Text("Net remaining: ${rs(plan.net)}", fontWeight = FontWeight.SemiBold)
            Text("Minimum saving: ${rs(plan.saving)}")
            Text("Kharch kar sakte ho: ${rs(plan.spendable)} / mahina", fontWeight = FontWeight.SemiBold)
            Text("Daily limit: ${rs(plan.dailyLimit)}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            plan.warning?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
fun Dashboard(dao: AppDao, p: Profile) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    val dayKey = today.toString()
    val monthKey = YearMonth.from(today).toString()
    val exps by dao.expenses().collectAsState(emptyList())
    val spent by dao.daySpentFlow(dayKey).collectAsState(0.0)
    val monthSpent by dao.monthSpentFlow(monthKey).collectAsState(0.0)
    val txns by dao.txnsOfDay(dayKey).collectAsState(emptyList())
    val reports by dao.reports().collectAsState(emptyList())
    val nCount by dao.notifCount(monthKey).collectAsState(0)
    val plan = Formula.compute(p.base(), exps.sumOf { it.amount }, p.savingPercent, today.lengthOfMonth())

    val smsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val postLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Aaj ($dayKey)", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Daily limit: ${rs(plan.dailyLimit)}")
                    Text("Aaj kharch: ${rs(spent)}", fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        color = if (spent > plan.dailyLimit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    Text("Is mahine kharch: ${rs(monthSpent)} / ${rs(plan.spendable)}")
                    Text("Is mahine ki notifications saved: $nCount", fontSize = 12.sp)
                }
            }
        }
        item { PlanCard(plan) }

        item { Text("Permissions (zaroori)", fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()) { Text("1. Notification Access ON karo") }
                OutlinedButton(onClick = { smsLauncher.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)) },
                    modifier = Modifier.fillMaxWidth()) { Text("2. SMS permission do") }
                OutlinedButton(onClick = { if (Build.VERSION.SDK_INT >= 33) postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    modifier = Modifier.fillMaxWidth()) { Text("3. Alerts bhejne ki permission") }
                OutlinedButton(onClick = {
                    if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                }, modifier = Modifier.fillMaxWidth()) { Text("4. Exact alarm (7 AM / 10 PM) allow") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()) { Text("5. Battery optimization off karo") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }, modifier = Modifier.fillMaxWidth()) { Text("Android 13+: App info → Allow restricted settings") }
            }
        }

        item { Text("Aaj ke transactions", fontWeight = FontWeight.Bold) }
        if (txns.isEmpty()) item { Text("Abhi koi bank message nahi mila.") }
        items(txns) { t ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (t.type == "DEBIT") "− ${rs(t.amount)}" else "+ ${rs(t.amount)}", fontWeight = FontWeight.SemiBold)
                    Text(t.type + " • " + t.source.substringAfterLast('.'), fontSize = 12.sp)
                }
            }
        }

        item { Text("Pichli daily reports", fontWeight = FontWeight.Bold) }
        if (reports.isEmpty()) item { Text("Pehli report raat 10 baje aayegi.") }
        items(reports) { r ->
            Text("${r.dayKey}: kharch ${rs(r.spent)} / limit ${rs(r.limit)} ${if (r.crossed) "❌" else "✅"}")
        }
    }
}
