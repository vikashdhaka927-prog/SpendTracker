package com.spendtracker.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.*
import java.time.LocalDate
import java.time.YearMonth
import java.util.Calendar

object Notifier {
    private const val CH = "spend_alerts"
    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Spend alerts", NotificationManager.IMPORTANCE_HIGH))
    }
    fun show(ctx: Context, id: Int, title: String, text: String) {
        ensureChannel(ctx)
        val n = Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true).build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: SecurityException) {}
    }
}

/** Reads every notification, stores it, and parses bank messages. */
class NotifListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val pkg = sbn.packageName
        val time = sbn.postTime
        val ctx = applicationContext
        scope.launch {
            val dao = AppDatabase.get(ctx).dao()
            dao.addNotif(NotifEntity(pkg = pkg, title = title, text = text, time = time,
                monthKey = YearMonth.now().toString(), isTruecaller = pkg == "com.truecaller"))
            if (pkg in Processor.smsPackages) Processor.handleText(ctx, "$title $text", pkg, time)
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}

/** Direct SMS (works when READ/RECEIVE_SMS granted, e.g. GitHub APK). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sender = msgs.firstOrNull()?.originatingAddress ?: ""
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { Processor.handleText(ctx, "$sender $body", "SMS", System.currentTimeMillis()) }
            finally { pending.finish() }
        }
    }
}

object Scheduler {
    fun scheduleAll(ctx: Context) { schedule(ctx, "MORNING", 7); schedule(ctx, "NIGHT", 22) }

    fun schedule(ctx: Context, action: String, hour: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, hour, Intent(ctx, DailyReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}

/** 7 AM greeting + 10 PM report. */
class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val action = intent.action ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(ctx).dao()
                val today = LocalDate.now()
                val limit = Processor.limitFor(dao, today)
                if (limit != null) {
                    val key = today.toString()
                    val spent = dao.daySpent(key)
                    if (action == "MORNING") {
                        Notifier.show(ctx, 200, "Good morning ☀️",
                            "Aaj aapki spend limit ₹${limit.toLong()} hai. Smart kharch karein!")
                    } else if (action == "NIGHT") {
                        val credited = dao.dayCredit(key)
                        val crossed = spent > limit
                        dao.saveReport(DailyReport(key, YearMonth.from(today).toString(), limit, spent, credited, crossed))
                        val verdict = if (crossed) "❌ Limit ₹${(spent - limit).toLong()} se cross hui"
                                      else "✅ ₹${(limit - spent).toLong()} bach gaye"
                        Notifier.show(ctx, 201, "Aaj ki report 🌙",
                            "Target ₹${limit.toLong()} tha, kharch ₹${spent.toLong()}, aaya ₹${credited.toLong()}. $verdict")
                    }
                }
            } finally {
                Scheduler.schedule(ctx, action, if (action == "MORNING") 7 else 22)
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.scheduleAll(ctx)
    }
}
