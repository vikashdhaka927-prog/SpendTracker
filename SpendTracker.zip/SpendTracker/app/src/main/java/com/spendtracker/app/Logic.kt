package com.spendtracker.app

import android.content.Context
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

data class Plan(
    val base: Double,
    val fixedTotal: Double,
    val net: Double,
    val saving: Double,
    val spendable: Double,
    val dailyLimit: Double,
    val warning: String?
)

object Formula {
    /**
     * net        = base - fixed expenses
     * saving     = base * savingPercent%   (default 20%)
     * spendable  = net - saving
     * dailyLimit = spendable / days in that month
     */
    fun compute(base: Double, fixedTotal: Double, savingPercent: Int, daysInMonth: Int): Plan {
        val net = base - fixedTotal
        var saving = base * savingPercent / 100.0
        var warning: String? = null
        var spendable = net - saving
        if (net <= 0) {
            saving = 0.0; spendable = 0.0
            warning = "Fix kharche income se zyada ya barabar hain. Kharche kam karo."
        } else if (spendable < 0) {
            saving = net; spendable = 0.0
            warning = "Itni saving possible nahi. Max saving ₹${net.toLong()} hi ho sakti hai."
        }
        return Plan(base, fixedTotal, net, saving, spendable, spendable / daysInMonth, warning)
    }
}

object TxnParser {
    data class Result(val amount: Double, val type: String)

    private val amountRx = Regex("""(?i)(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)""")
    private val skip = listOf("otp", "one time password", "request", "due by", "due on", "offer", "loan approved")
    private val bankWords = listOf("a/c", "acct", "account", "upi", "bank", "txn", "imps", "neft", "atm", "card", "debited", "credited")
    private val debitWords = listOf("debited", "spent", "withdrawn", "paid", "purchase", "sent")
    private val creditWords = listOf("credited", "received", "deposited")

    private fun first(t: String, words: List<String>): Int =
        words.map { t.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: -1

    fun parse(text: String): Result? {
        val t = text.lowercase()
        if (skip.any { it in t }) return null
        if (bankWords.none { it in t }) return null
        val m = amountRx.find(text) ?: return null
        val amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        val d = first(t, debitWords)
        val c = first(t, creditWords)
        val type = when {
            d == -1 && c == -1 -> return null
            c == -1 -> "DEBIT"
            d == -1 -> "CREDIT"
            d < c -> "DEBIT"
            else -> "CREDIT"
        }
        return Result(amt, type)
    }
}

object Processor {
    /** Apps whose notifications we treat as possible bank SMS. */
    val smsPackages = setOf(
        "com.truecaller",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.android.mms",
        "com.android.messaging",
        "com.miui.mms"
    )

    suspend fun handleText(ctx: Context, text: String, source: String, time: Long) {
        val r = TxnParser.parse(text) ?: return
        val dao = AppDatabase.get(ctx).dao()
        val ld = Instant.ofEpochMilli(time).atZone(ZoneId.systemDefault()).toLocalDate()
        val dayKey = ld.toString()
        val monthKey = YearMonth.from(ld).toString()
        // same SMS can arrive via SMS receiver and notification: dedupe by minute bucket
        val dedup = "$dayKey|${r.amount}|${r.type}|${time / 60000}"
        val id = dao.addTxn(Txn(amount = r.amount, type = r.type, body = text, source = source,
            time = time, dayKey = dayKey, monthKey = monthKey, dedupKey = dedup))
        if (id == -1L) return
        if (r.type == "DEBIT" && ld == LocalDate.now()) checkLimit(ctx, dao, ld)
    }

    suspend fun limitFor(dao: AppDao, date: LocalDate): Double? {
        val p = dao.profileOnce() ?: return null
        val fixed = dao.expensesOnce().sumOf { it.amount }
        return Formula.compute(p.base(), fixed, p.savingPercent, date.lengthOfMonth()).dailyLimit
    }

    private suspend fun checkLimit(ctx: Context, dao: AppDao, date: LocalDate) {
        val limit = limitFor(dao, date) ?: return
        val spent = dao.daySpent(date.toString())
        if (spent > limit) {
            Notifier.show(ctx, 100, "⚠️ Aaj ki limit cross!",
                "Limit ₹${limit.toLong()}, kharch ₹${spent.toLong()} (₹${(spent - limit).toLong()} zyada).")
        }
    }
}
