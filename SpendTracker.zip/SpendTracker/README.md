# Spend Tracker (Android, Kotlin + Compose + Room)

Offline expense tracker: income + fixed expenses -> daily spend limit, auto-tracks bank
debit/credit from notifications and SMS, 7 AM greeting and 10 PM report.

## Build
Open this folder in Android Studio (Koala+), let Gradle sync, Run. Or push to GitHub and add a
GitHub Actions workflow that runs `./gradlew assembleDebug`.

## Setup on phone (important)
1. Notification Access ON (Settings > Notification access > Spend Tracker).
2. Android 13+ sideloaded APK: App info > three dots > **Allow restricted settings**, then step 1.
3. Allow SMS, post-notification and exact-alarm permissions.
4. Battery optimization OFF (Xiaomi/Oppo/Vivo: also enable Autostart).

## Formula
net = income - fixed expenses; saving = income x 20% (adjustable);
spendable = net - saving; daily limit = spendable / days in month.

## Data
All data stays in a local Room DB (spend.db). Nothing is deleted at month change;
every row carries `monthKey` (yyyy-MM). Cloud sync can be added later.

## Note
SMS permissions are restricted on Google Play, so distribute via GitHub APK.
